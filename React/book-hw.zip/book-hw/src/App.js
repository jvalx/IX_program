import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import bookInputs from './components/bookInputs';
import bookTable from './components/bookTable';

export default function App() {
  return (
    <div className=' container mt-4'>
      <div className= 'card card-body text-center'>
        <h1>Add Book</h1>
        <bookInputs> </bookInputs>
        <bookTable> </bookTable>
        
      </div>
    </div>
  )
}

