import React from 'react';

export default function bookInputs() {
    return (
        <div className='mt-4'>
            <div className="input-group mb-3">
                <label for="exampleFormControlInput1" className="form-label">Email address</label>
                <input type="email" className="form-control" 
                id="exampleFormControlInput1" 
                placeholder="name@example.com"/>

                <label for="exampleFormControlInput1" className="form-label">Email address</label>
                <input type="email" className="form-control" 
                id="exampleFormControlInput1" 
                placeholder="name@example.com"/>

                <label for="exampleFormControlInput1" className="form-label">Email address</label>
                <input type="email" className="form-control" 
                id="exampleFormControlInput1" 
                placeholder="name@example.com"/>
            </div>
        </div>
    )
}
