

export class Book {
    constructor(id, title, author, ISBN) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
    }
}